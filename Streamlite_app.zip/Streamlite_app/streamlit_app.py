import streamlit as st
from streamlit_lottie import st_lottie
import json
import os
from audio_recorder_streamlit import audio_recorder
# These must exist in your backend folder
from backend.audio_utils import save_audio_file, extract_audio_features
from backend.model import classify_media
import matplotlib.pyplot as plt
import librosa.display
import base64

background_image_url = "https://images.unsplash.com/photo-1504384308090-c894fdcc538d?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80"

# --- CSS for background image and extra-large text ---
st.markdown(
    f"""
    <style>
    .stApp {{
        position: relative;
        min-height: 100vh;
    }}
    .stApp::before {{
        content: "";
        position: fixed;
        top: 0;
        left: 0;
        width: 100vw;
        height: 100vh;
        background-image: url("{background_image_url}");
        background-size: cover;
        background-position: center;
        opacity: 0.2;
        z-index: 0;
        pointer-events: none;
    }}
    .block-container {{
        position: relative;
        z-index: 1;
    }}
    .huge-title {{
        font-size: 3rem !important;
        font-weight: bold;
        text-align: center;
        margin-bottom: 2rem;
        margin-top: 1rem;
    }}
    .big-label {{
        font-size: 1.7rem !important;
        font-weight: 700;
        margin-bottom: 1rem;
    }}
    .result-text {{
        font-size: 2.2rem !important;
        font-weight: bold;
        margin-top: 2rem;
        margin-bottom: 1rem;
        text-align: center;
    }}
    .prob-text {{
        font-size: 1.5rem !important;
        text-align: center;
    }}
    </style>
    """,
    unsafe_allow_html=True
)

st.markdown('<div class="huge-title">Truth or Trap: Fake Speech Detection Using Deep Learning</div>', unsafe_allow_html=True)
st.markdown('<br>', unsafe_allow_html=True)

# --- Toggle button for Upload or Record ---
option = st.radio(
    "Choose your input method:",
    ("Upload file", "Record audio"),
    horizontal=True
)

audio_data = None
audio_filename = None

if option == "Upload file":
    st.markdown('<div class="big-label">Upload file</div>', unsafe_allow_html=True)
    uploaded_file = st.file_uploader(
        "",
        type=["wav", "mp3", "ogg"],
        key="upload"
    )
    if uploaded_file is not None:
        st.audio(uploaded_file)
        st.success("Audio file uploaded successfully!")
        audio_data = uploaded_file.read()
        audio_filename = uploaded_file.name
        with open(audio_filename, "wb") as f:
            f.write(audio_data)
        st.info(f"Uploaded audio saved as {audio_filename}")

elif option == "Record audio":
    st.markdown('<div class="big-label">Record audio</div>', unsafe_allow_html=True)
    audio_value = st.audio_input("", key="record")
    if audio_value is not None:
        st.success("Audio recorded successfully!")
        audio_data = audio_value.read()
        audio_filename = "recorded_audio.wav"
        with open(audio_filename, "wb") as f:
            f.write(audio_data)
        st.info(f"Recorded audio saved as {audio_filename}")

# --- Analysis and Visualization ---
if audio_data and audio_filename:
    file_path = save_audio_file(audio_data, audio_filename)
    features = extract_audio_features(file_path)
    
    st.text(f"MFCCs shape: {features['mfccs'].shape}")
    st.text(f"Mel Spectrogram shape: {features['mel_spec'].shape}")
    st.text(f"Log-Mel Spectrogram shape: {features['log_mel_spec'].shape}")

    # Plot the Log-Mel Spectrogram
    fig, ax = plt.subplots(figsize=(10, 4))
    im = librosa.display.specshow(features['log_mel_spec'], sr=features['sr'], x_axis='time', y_axis='mel', ax=ax)
    ax.set_title("Log-Mel Spectrogram")
    fig.colorbar(im, ax=ax, format="%+2.0f dB")
    st.pyplot(fig)

    # Dummy classifier result (can be replaced with actual model)
    with st.spinner("🔎 Analyzing..."):
        result = classify_media(audio_filename)

    st.subheader("Prediction:")
    if result == "Real":
        st.success("🟢 The content is REAL")
    else:
        st.error("🔴 The content is FAKE")

    # Load Lottie animation
    def load_lottie_file(filepath: str):
        with open(filepath, "r") as f:
            return json.load(f)

    # Load the local Lottie animation
    lottie_data_real = load_lottie_file("C:/Users/NARENDRA MANETTIWAR/Desktop/nani/OneDrive/Documents/DL/Animation - 1746223799791.json")
    lottie_data_fake = load_lottie_file("C:/Users/NARENDRA MANETTIWAR/Desktop/nani/OneDrive/Documents/DL/Animation - 1746223799791.json")

    # Show the corresponding Lottie animation based on the result
    if result == "Real":
        st_lottie(lottie_data_real, speed=1, width=700, height=700, key="local_animation")
    else:
        st_lottie(lottie_data_fake, speed=1, width=700, height=700, key="local_animation")

# ---- Footer ----
st.markdown("---")
st.markdown("<h3 style='text-align: center; color: white;'>Made by group 43</h3>", unsafe_allow_html=True)
