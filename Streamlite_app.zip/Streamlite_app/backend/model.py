import os
import torch
import torchaudio
import timm
#import librosa
import numpy as np
import matplotlib.pyplot as plt
from torch import nn
from torch.utils.data import Dataset, DataLoader
from sklearn.manifold import TSNE
from sklearn.metrics import confusion_matrix, classification_report
import seaborn as sns
#import gradio as gr
from hear21passt.base import get_basic_model, get_model_passt
from torch.optim import AdamW
from collections import defaultdict
import torch.nn.functional as F
from glob import glob
import os
import librosa
import numpy as np
import hashlib
import matplotlib.pyplot as plt
from tqdm import tqdm
import tensorflow as tf
from tensorflow.keras.models import Sequential, Model
from tensorflow.keras.layers import Dense, Dropout, Flatten, Conv2D, MaxPooling2D, LSTM, Input
from tensorflow.keras.applications import VGG16
from tensorflow.keras.utils import to_categorical
from tensorflow.keras.callbacks import ModelCheckpoint, EarlyStopping
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix
import pandas as pd
import joblib

SAMPLE_RATE = 32000
N_MELS = 128
MAX_LENGTH = 512

## MODEL

# ----------- MODEL -----------
class PaSSTClassifier(nn.Module):
    def __init__(self):
        super().__init__()
        self.backbone = get_basic_model(mode="logits")
        self.backbone.net = get_model_passt(arch="passt_s_swa_p16_128_ap476", n_classes=512)  # Use default output size
        self.mlp = nn.Sequential(
            nn.Linear(512, 256),
            nn.ReLU(),
            nn.Dropout(0.3),
            nn.Linear(256, 64),
            nn.ReLU(),
            nn.Dropout(0.3),
            nn.Linear(64,2),
        )

    def forward(self, x):
        x, _ = self.backbone.net(x)
        x = self.mlp(x)
        return x
    
def create_vgg16_model(input_shape):
    """Create a VGG16-based transfer learning model"""
    # Create a base model from VGG16 without the top layer
    base_model = VGG16(weights='imagenet', include_top=False, input_shape=(64, 64, 3))
    
    # Freeze the base model layers
    for layer in base_model.layers:
        layer.trainable = False
    
    # Create new model
    inputs = Input(shape=input_shape)
    
    # Convert grayscale to 3-channel (if input is grayscale)
    if input_shape[-1] == 1:
        x = tf.keras.layers.Conv2D(3, (1, 1), padding='same')(inputs)
    else:
        x = inputs
    
    # Resize to 64x64 if needed
    x = tf.keras.layers.Resizing(64, 64)(x)
    
    # Pass through the VGG16 model
    x = base_model(x)
    
    # Add classification layers
    x = Flatten()(x)
    x = Dense(256, activation='relu')(x)
    x = Dropout(0.5)(x)
    x = Dense(128, activation='relu')(x)
    x = Dropout(0.3)(x)
    outputs = Dense(2, activation='softmax')(x)
    
    # Create the model
    model = Model(inputs=inputs, outputs=outputs)
    
    # Compile the model
    model.compile(
        optimizer='adam',
        loss='categorical_crossentropy',
        metrics=['accuracy']
    )
    
    return model

def create_lstm_model(input_shape):
    """Create an LSTM model for MFCC sequence analysis"""
    # Reshape input to be suitable for LSTM (samples, time steps, features)
    lstm_input_shape = (input_shape[1], input_shape[0])  # (time_steps, features)
    
    model = Sequential([
        Input(shape=input_shape),
        tf.keras.layers.Reshape(lstm_input_shape),
        LSTM(128, return_sequences=True),
        Dropout(0.2),
        LSTM(64),
        Dropout(0.2),
        Dense(32, activation='relu'),
        Dense(2, activation='softmax')
    ])
    
    # Compile the model
    model.compile(
        optimizer='adam',
        loss='categorical_crossentropy',
        metrics=['accuracy']
    )
    
    return model

def preprocess_audio(file_path, max_length=MAX_LENGTH):

    waveform, _ = torchaudio.load(file_path)
    waveform = waveform.mean(dim=0, keepdim=True)  # convert to mono

    mel_spec = torchaudio.transforms.MelSpectrogram(
        sample_rate=SAMPLE_RATE, n_mels=N_MELS)(waveform)
    mel_spec_db = torchaudio.transforms.AmplitudeToDB()(mel_spec)

    # Pad or truncate to fixed length
    if mel_spec_db.size(-1) < max_length:
        pad_amt = max_length - mel_spec_db.size(-1)
        mel_spec_db = F.pad(mel_spec_db, (0, pad_amt))
    else:
        mel_spec_db = mel_spec_db[:, :, :max_length]

    return mel_spec_db

def predict_ir(file_path, model, device):

    model.eval()
    input_tensor = preprocess_audio(file_path).unsqueeze(0).to(device)

    with torch.no_grad():
        output = model(input_tensor)
        probs = torch.softmax(output, dim=1)
        pred_idx = torch.argmax(probs, dim=1).item()
        label = "real" if pred_idx == 0 else "fake"

    return {"label": label, "confidence": probs.cpu().numpy().tolist()[0]}


model = PaSSTClassifier()
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
state_dict = torch.load(r"C:\Users\Mourya Kondawar\Downloads\DL\passt_weights_full_dataset.pth", map_location=device)  # replace with actual filename
model.load_state_dict(state_dict)
model.to(device)
model.eval()

def classify_media(file_path):
    result = predict_ir(file_path, model, device)
    return result

s = classify_media(r"C:\Users\Mourya Kondawar\Downloads\DL\file1047.wav_16k.wav_norm.wav_mono.wav_silence.wav")
print(s)

