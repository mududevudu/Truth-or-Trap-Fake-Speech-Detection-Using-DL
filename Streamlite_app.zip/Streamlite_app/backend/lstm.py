import numpy as np
import librosa
import tensorflow as tf
from tensorflow.keras.models import Model, Sequential
from tensorflow.keras.layers import Input, Flatten, Dense, Dropout, LSTM, Conv2D, Resizing
from tensorflow.keras.applications import VGG16
import os

CLASS_NAMES = ['real', 'fake']  # Index 0 = real, 1 = fake

# --------- Preprocessing (librosa, MFCC) ----------
def extract_normalized_mfcc(file_path, sr=16000, n_mfcc=40, max_len=64):
    y, _ = librosa.load(file_path, sr=sr)
    if len(y) < sr:
        y = np.pad(y, (0, sr - len(y)))
    mfcc = librosa.feature.mfcc(y=y, sr=sr, n_mfcc=n_mfcc)
    mfcc = (mfcc - np.mean(mfcc)) / (np.std(mfcc) + 1e-8)
    if mfcc.shape[1] < max_len:
        pad_width = max_len - mfcc.shape[1]
        mfcc = np.pad(mfcc, ((0, 0), (0, pad_width)))
    else:
        mfcc = mfcc[:, :max_len]
    return mfcc.astype(np.float32)  # shape (40, 64)


# --------- LSTM Model Definition ----------
def create_lstm_model(input_shape=(40, 64)):
    model = Sequential([
        Input(shape=input_shape),
        tf.keras.layers.Reshape((64, 40)),  # time_steps, features
        LSTM(128, return_sequences=True),
        Dropout(0.2),
        LSTM(64),
        Dropout(0.2),
        Dense(32, activation='relu'),
        Dense(2, activation='softmax')
    ])
    model.compile(optimizer='adam', loss='categorical_crossentropy', metrics=['accuracy'])
    return model


def infer_with_lstm(file_path, weights_path):
    mfcc = extract_normalized_mfcc(file_path)  # (40, 64)
    model = create_lstm_model(input_shape=(40, 64))
    model.load_weights(weights_path)
    probs = model.predict(np.expand_dims(mfcc, axis=0))[0]
    return {"label": CLASS_NAMES[np.argmax(probs)], "confidence": probs.tolist()}


# --------- Example Usage ----------
if __name__ == "__main__":
    file_path = "file1047.wav_16k.wav_norm.wav_mono.wav_silence.wav"
    
    lstm_result = infer_with_lstm(file_path, r"C:\Users\Mourya Kondawar\Downloads\DL\backend\norm_lstm_model.h5")
    print("LSTM Result:", lstm_result)