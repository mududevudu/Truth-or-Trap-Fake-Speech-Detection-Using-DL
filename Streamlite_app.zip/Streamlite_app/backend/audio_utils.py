import librosa
import numpy as np

def save_audio_file(file_data, filename):
    with open(filename, "wb") as f:
        f.write(file_data)
    return filename

def extract_audio_features(file_path):
    y, sr = librosa.load(file_path, sr=16000)
    mfccs = librosa.feature.mfcc(y=y, sr=sr, n_mfcc=13)
    mel_spec = librosa.feature.melspectrogram(y=y, sr=sr, n_mels=128)
    log_mel_spec = librosa.power_to_db(mel_spec, ref=np.max)

    return {
        "mfccs": mfccs,
        "mel_spec": mel_spec,
        "log_mel_spec": log_mel_spec,
        "sr": sr,
    }
