import numpy as np
import librosa
import tensorflow as tf
from tensorflow.keras.models import Model, Sequential
from tensorflow.keras.layers import Input, Flatten, Dense, Dropout, LSTM, Conv2D, Resizing
from tensorflow.keras.applications import VGG16
import os

CLASS_NAMES = ['real', 'fake']  # Index 0 = real, 1 = fake

# --------- Preprocessing (librosa, MFCC) ----------
def extract_normalized_mfcc(file_path, sr=16000, n_mfcc=40, max_len=64):
    y, _ = librosa.load(file_path, sr=sr)
    if len(y) < sr:
        y = np.pad(y, (0, sr - len(y)))
    mfcc = librosa.feature.mfcc(y=y, sr=sr, n_mfcc=n_mfcc)
    mfcc = (mfcc - np.mean(mfcc)) / (np.std(mfcc) + 1e-8)
    if mfcc.shape[1] < max_len:
        pad_width = max_len - mfcc.shape[1]
        mfcc = np.pad(mfcc, ((0, 0), (0, pad_width)))
    else:
        mfcc = mfcc[:, :max_len]
    return mfcc.astype(np.float32)  # shape (40, 64)

# --------- VGG16 Model Definition ----------
def create_vgg16_model(input_shape=(64, 64, 3)):
    base_model = VGG16(weights='imagenet', include_top=False, input_shape=input_shape)
    for layer in base_model.layers:
        layer.trainable = False

    inputs = Input(shape=input_shape)
    x = Conv2D(3, (1, 1), padding='same')(inputs)
    x = Resizing(64, 64)(x)
    x = base_model(x)
    x = Flatten()(x)
    x = Dense(256, activation='relu')(x)
    x = Dropout(0.5)(x)
    x = Dense(128, activation='relu')(x)
    x = Dropout(0.3)(x)
    outputs = Dense(2, activation='softmax')(x)
    model = Model(inputs, outputs)
    model.compile(optimizer='adam', loss='categorical_crossentropy', metrics=['accuracy'])
    return model

# --------- Inference using VGG ----------
def infer_with_vgg(file_path, weights_path):
    mfcc = extract_normalized_mfcc(file_path)  # shape (40, 64)
    mfcc_resized = tf.image.resize(np.expand_dims(mfcc, axis=-1), (64, 64))  # shape (64, 64, 1)
    image = np.repeat(mfcc_resized.numpy(), 3, axis=-1) / 255.0  # shape (64, 64, 3)
    model = create_vgg16_model(input_shape=(64, 64, 3))
    model.load_weights(weights_path)
    probs = model.predict(np.expand_dims(image, axis=0), verbose=0)[0]
    return {"label": CLASS_NAMES[np.argmax(probs)], "confidence": probs.tolist()}

# --------- Example Usage ----------
if __name__ == "__main__":
    file_path = "file1047.wav_16k.wav_norm.wav_mono.wav_silence.wav"
    
    vgg_result = infer_with_vgg(file_path, r"C:\Users\Mourya Kondawar\Downloads\DL\backend\norm_vgg16_weights.h5")
    print("VGG16 Result:", vgg_result)
